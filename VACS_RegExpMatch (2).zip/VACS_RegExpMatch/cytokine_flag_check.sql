--delete from cytokine_lookup_regex
--possible=58, definite=43,unlikely=14 (train)
--possible=467, definite=1556,unlikely=84 (test)

--Test Dataset
SELECT *
into cytokine_lookup_regex_bkp
FROM cytokine_lookup_regex

SELECT *
FROM cytokine_lookup_regex
WHERE tiudocumentsid = 1400789390149 --cytokinecode = 'unlikely'

SELECT MAX([referencedatetime])
FROM [dbo].[Cytokine_storm_snips_20200520]


--Training dataset
--Both definite
SELECT *
FROM cytokine_lookup 
WHERE snippet IN (SELECT snippet FROM cytokine_lookup_regex WHERE cytokinecode = 'definite')
and cytokinecode = 'definite'

--Not flagged 
SELECT *
FROM cytokine_lookup 
WHERE snippet not in (SELECT snippet FROM cytokine_lookup_regex)
and cytokinecode = 'definite'

--Both possible
SELECT *
FROM cytokine_lookup_regex
WHERE cytokinecode = 'possible'
AND snippet IN (SELECT snippet FROM cytokine_lookup_regex WHERE cytokinecode = 'possible')

--Not flagged
SELECT *
FROM cytokine_lookup 
WHERE snippet not in (SELECT snippet FROM cytokine_lookup_regex)
and cytokinecode = 'possible'

--Both unlikey
SELECT *
FROM cytokine_lookup_regex
WHERE cytokinecode = 'unlikely'
AND snippet IN (SELECT snippet FROM cytokine_lookup_regex WHERE cytokinecode = 'unlikely')

--Not flagged
SELECT *
FROM cytokine_lookup 
WHERE snippet not in (SELECT snippet FROM cytokine_lookup_regex)
and cytokinecode = 'unlikely'


--Sandbox
delete from cytokine_lookup_regex

SELECT *
FROM cytokine_lookup_regex
order by cytokinecode







