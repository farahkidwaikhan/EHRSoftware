--Step1
EXEC SP_CONFIGURE 'SHOW ADVANCED OPTIONS', '1';
GO
RECONFIGURE;
GO
EXEC SP_CONFIGURE 'CLR ENABLED' , '1'
GO
RECONFIGURE


--Step2(done on server)
ALTER DATABASE VACS_TIU SET TRUSTWORTHY ON;
USE VACS_TIU EXEC sp_changedbowner 'vha01\vhaconkidwaf'

DROP PROCEDURE RegExpMatch
DROP ASSEMBLY VACS_RegExpMatch
CREATE ASSEMBLY VACS_RegExpMatch
FROM 'C:\Users\VHACONKIDWAF\Documents\VACS_RegExpMatch\bin\Debug\VACS_RegExpMatch.dll'
WITH PERMISSION_SET = EXTERNAL_ACCESS


CREATE PROCEDURE RegExpMatch (@Pattern nvarchar(max)) AS
EXTERNAL NAME [VACS_RegExpMatch].[VACS_RegExpMatch.MatchRegExp].[MatchPattern]

--Execute Procedure
DECLARE	@return_value int
EXECUTE @return_value = [dbo].[RegExpMatch]  N'cytokine_lookup'
SELECT	'Return Value' = @return_value
GO

--sandbox
DROP TYPE input_table
CREATE TYPE input_table AS TABLE(notes varchar(8000))
DECLARE	@return_value int
DECLARE @notes AS nVARCHAR(max)
INSERT INTO input_table SELECT REPLACE(UPPER(sys.fn_sqlvarbasetostr(CONVERT(VARCHAR,[snippet]))),'X','x') snippet FROM cytokine_lookup
SET @notes = (SELECT  SUBSTRING(
        (
            SELECT '*'+snippet  AS [text()]
            FROM cytokine_lookup
            FOR XML PATH ('')
        ), 1, 3000) snippet)
 










