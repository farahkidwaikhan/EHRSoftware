Imports System.Text.RegularExpressions


Public Class MatchRegExp


    Shared Function MatchPattern(ByVal Intxt As String, Optional ByVal Inpattern As String = "") As String
        Dim oRegex1 As New Regex("COMMENT" & "," & "SEE CHART" & "," & "SEE BELOW" & "," & "SEE NOTE" & "," & "PENDING" & "," & "DONE" & "," & "NA" & "," & "N/A" & "," & "NO COMPLIMENTING TEST" & "," & "TNP" & "," & "QNS" & "," & "Q.N.S" & "," & "$" & "," & "@" & "," & "#" & "," & "*" & "," & "NOT DONE" & "," & "NOT AVAILABLE" & "," & "ND" & "," & "REQUESTED" & "," & "CANCELED")
        Dim oRegex2 As New Regex("(?m)^([^,]*), (.*)$")
        Dim i As Integer
        Dim pattern As String = oRegex2.Replace(oRegex1.ToString, "$2$1")
        Dim patternmodified As String = pattern
        Dim strSplit As String = ""
        Dim strReturn As String = " "

        If Inpattern <> "" Then
            pattern = pattern & "," & Inpattern
            patternmodified = pattern
        End If


        Try
            For i = 0 To patternmodified.Length
                'Loop through each element in the defined string
                If patternmodified.IndexOf(",") > 0 Then
                    strSplit = patternmodified.Substring(0, patternmodified.IndexOf(","))
                    patternmodified = patternmodified.Substring(strSplit.Length + 1)
                Else
                    strSplit = patternmodified
                End If
                'Compare Input to Patterns
                If strSplit = Intxt.ToUpper Then
                    strReturn = "Match Found" & " " & strSplit
                    Exit For
                Else
                    Dim strlike As String = Intxt.ToUpper & "*"
                    If strSplit Like strlike Then
                        strReturn = "Partial Match Found" & " " & strSplit
                        Exit For
                    Else
                        strReturn = "Match not found"
                    End If
                End If
            Next
        Catch ex As Exception
            strReturn = "Error"
        End Try

        If strReturn = "" Then
            strReturn = "Match not found!"
        End If

        Return strReturn

    End Function


End Class
