--Step1
EXEC SP_CONFIGURE 'SHOW ADVANCED OPTIONS', '1';
GO
RECONFIGURE;
GO
EXEC SP_CONFIGURE 'CLR ENABLED' , '1'
GO
RECONFIGURE


--Step2(done on server)


CREATE ASSEMBLY VACS_RegExpMatch
FROM 'C:\Documents and Settings\vhaconkidwaf\My Documents\Visual Studio 2005\Projects\VACS_RegExpMatch\VACS_RegExpMatch\bin\Debug\VACS_RegExpMatch.dll'
WITH PERMISSION_SET = EXTERNAL_ACCESS

CREATE ASSEMBLY Test_CLR
FROM 'C:\Documents and Settings\vhaconkidwaf\My Documents\Visual Studio 2005\Projects\Test_CLR\Test_CLR\bin\Debug\Test_CLR.dll'
WITH PERMISSION_SET = EXTERNAL_ACCESS

use master

ALTER DATABASE MASTER SET TRUSTWORTHY ON

USE [master]
GO
/****** Object:  UserDefinedFunction [dbo].[RegExpMatch]    Script Date: 09/27/2007 10:54:24 ******/
CREATE FUNCTION [dbo].[RegExpMatch](@Result [nvarchar](4000), @Pattern [nvarchar](4000))
RETURNS [nvarchar](4000) WITH EXECUTE AS CALLER
AS
EXTERNAL NAME [VACS_RegExpMatch].[VACS_RegExpMatch.MatchRegExp].[MatchPattern]

USE [master]
GO
/****** Object:  UserDefinedFunction [dbo].[RegExpMatch]    Script Date: 09/26/2007 13:55:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RegExpMatch]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[RegExpMatch]