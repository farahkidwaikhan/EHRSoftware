Imports System.Text.RegularExpressions
Public Class MatchRegExp
    Public Shared Sub MatchPattern(ByVal Intxt As String)
        Dim oRegex1 As New Regex("COMMENT" & "," & "SEE CHART" & "," & "SEE BELOW" & "," & "SEE NOTE" & "," & "PENDING" & "," & "DONE" & "," & "NA" & "," & "N/A" & "," & "NO COMPLIMENTING TEST" & "," & "TNP" & "," & "QNS" & "," & "Q.N.S" & "," & "$" & "," & "@" & "," & "#" & "," & "*" & "," & "NOT DONE" & "," & "NOT AVAILABLE" & "," & "ND" & "," & "REQUESTED")
        Dim oRegex2 As New Regex("(?m)^([^,]*), (.*)$")
        Dim i As Integer
        Dim pattern As String = oRegex2.Replace(oRegex1.ToString, "$2$1")
        Dim patternmodified As String = pattern
        Dim strSplit As String = ""
        Try
            For i = 0 To 20
                'Loop through each element in the defined string
                If patternmodified.IndexOf(",") > 0 Then
                    strSplit = patternmodified.Substring(0, patternmodified.IndexOf(","))
                    patternmodified = patternmodified.Substring(strSplit.Length + 1)
                Else
                    strSplit = patternmodified
                End If

                'Compare Input to Patters
                If strSplit = Intxt Then
                    MsgBox("Match Found" & " " & strSplit)
                Else
                    Dim strlike As String = Intxt & "*"

                    If strSplit Like strlike Then
                        MsgBox("Partial Match Found" & " " & strSplit)

                    End If
                End If
            Next
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try


    End Sub
End Class
