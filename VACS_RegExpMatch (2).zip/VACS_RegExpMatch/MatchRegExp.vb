'Imports System.Data.SqlTypes
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Text.RegularExpressions
Imports Microsoft.SqlServer.Server

Public Class MatchRegExp
    Public Shared Sub MatchPattern(ByVal Intxt As String)
        'Dim strDefinite As String = ("cytokine storm treated" & ", " & "going through cytokine" & ", " & "going thru cytokine" & ", " & "covid related cytokine" & ", " & "causing the cytokine" & ", " & "causing cytokine" & ", " & "improving cytokine" & ", " & "sepsis, cytokine" & ", " & "address cytokine" & ", " & "offset cytokine" & ", " & "hypoxic respiratory failure" & ", " & "into cytokine" & ", " & "cytokine therapy" & ", " & "dampen cytokine storm" & ", " & "improvement of cytokine" & ", " & "associated cytokine" & ", " & "high cytokine" & ", " & "inflammatory markers uptrending" & ", " & "inflammation/cytokine" & ", " & "elevated cytokine" & ", " & "overt cytokine" & ", " & "cytokine cascade" & ", " & "storm/sepsis" & ", " & "related to cytokine" & ", " & "significant cytokine" & ", " & "+cytokine" & ", " & "#cytokine" & ", " & "moderate cytokine" & ", " & "acute cytokine" & ", " & "inflammatory cytokine response" & ", " & "inflammatory cytokines" & ", " & "resulting cytokine" & ", " & "indication of cytokine" & ", " & "includes cytokine release" & ", " & "cytokine storm/inflammation" & ", " & "covid inlammation" & ", " & "downtrending inflammatory" & ", " & "poor prognistic factors" & ", " & "covid cytokine storm" & ", " & "worsening covid/cytokine" & ", " & "cytokine induced" & ", " & "poor prognosis" & ", " & "driven cytokine" & ", " & "worsening syndrome" & ", " & "covid cytokine" & ", " & "in cytokine" & ", " & "includes cytokine release" & ", " & "treatment of cytokine" & ", " & "cytokine storm from the covid" & ", " & "in cytokine storm" & ", " & "worsening of cytokine" & ", " & "beginning of cytokine" & ", " & "covid pneumonia" & ", " & "cytokine inflammatory response" & ", " & "cytokine syndrom associated with covid19" & ", " & "cytokine driven" & ", " & "high inflammatory markers" & ", " & "covid positive" & ", " & "worsening tachypnea" & ", " & "developing cytokine" & ", " & "signs of cytokine" & ", " & "cytokine release from covid" & ", " & "cytokine storm from covid" & ", " & "inflammatory response and cytokine" & ", " & "w/cytokine storm" & ", " & "severe cytokine" & ", " & "COVID-19 induced organ failure" & ", " & "past cytokine" & ", " & "blunting the cytokine" & ", " & "SARS-CoV2 pneumonia" & ", " & "COVID-19 pneumonia and cytokine storm" & ", " & "Cytokine Release Syndrome associated with  Covid-19" & ", " & "have cytokine storm" & ", " & "covid-19 infection" & ", " & "for cytokine release" & ", " & "inflammatory response/cytokine" & ", " & "reflecting cytokine storm" & ", " & "2/2 to cytokine" & ", " & "likelihood of cytokine" & ", " & "covid-19 infection" & ", " & "cytokine mediated" & ", " & "likely from cytokine" & ", " & "combat cytokine release" & ", " & "midst of a cytokine" & ", " & "in light of cytokine" & ", " & "evidence for cytokine" & ", " & "covid-19 pneumonia" & ", " & "consistent with cytokine" & ", " & "continuing cytokine" & ", " & "probable cytokine" & ", " & "with cytokine" & ", " & "due to cytokine" & ", " & "covid19 induced cytokine" & ", " & "c/w cytokine" & ", " & "likely cytokine" & ", " & "presumed cytokine" & ", " & "evidence for cytokine" & ", " & "suspicion for cytokine" & ", " & "features for cytokine" & ", " & "cytokine blockade" & ", " & "2/2 cytokine" & ", " & "covid-19" & ", " & "experiencing cytokine" & ", " & "storm AKI" & ", " & "following cytokine" & ", " & "cytokine related" & ", " & "ongoing cytokine" & ", " & "most likely" & ", " & "highly consistent" & ", " & "consistent with cytokine" & ", " & "elevated inflammatory" & ", " & "Strong suspicion" & ", " & "induced cytokine" & ", " & "ongoing cytokine" & ", " & "continuing cytokine" & ", " & "evidence for cytokine" & ", " & "covid19 pneumonia" & ", " & "evidence of cytokine release" & ", " & "features of cytokine" & ", " & "storm syndrome" & ", " & "combat the cytokine" & ", " & "worsening due to cytokine" & ", " & "underlying COVID" & ", " & "worsening cytokine" & ", " & "ARDS")
        Dim strDefinite As String = ("cytokine storm requiring" & ", " & "cytokine storm-s/p" & ", " & "shock / cytokine" & ", " & "septic shock" & ", " & "post-cytokine" & ", " & "cytokine storm associated with" & ", " & "cytokine storm treated" & ", " & "going through cytokine" & ", " & "going thru cytokine" & ", " & "causing cytokine" & ", " & "help with the cytokine" & ", " & "s/o covid19 infection/ cytokine " & ", " & "inflammation + cytokine" & ", " & "cytokine-s/p" & ", " & "cytokine s/p" & ", " & "improving cytokine" & ", " & "address cytokine" & ", " & "offset cytokine" & ", " & "hypoxic respiratory failure" & ", " & "into cytokine" & ", " & "cytokine therapy" & ", " & "dampen cytokine storm" & ", " & "improvement of cytokine" & ", " & "associated cytokine" & ", " & "high cytokine" & ", " & "inflammatory markers uptrending" & ", " & "inflammation/cytokine" & ", " & "elevated cytokine" & ", " & "overt cytokine" & ", " & "cytokine cascade" & ", " & "storm/sepsis" & ", " & "related to cytokine" & ", " & "significant cytokine" & ", " & "+cytokine" & ", " & "#cytokine" & ", " & "moderate cytokine" & ", " & "acute cytokine" & ", " & "inflammatory cytokine response" & ", " & "inflammatory cytokines" & ", " & "resulting cytokine" & ", " & "indication of cytokine" & ", " & "includes cytokine release" & ", " & "cytokine storm/inflammation" & ", " & "covid inlammation" & ", " & "downtrending inflammatory" & ", " & "poor prognistic factors" & ", " & "covid cytokine storm" & ", " & "worsening covid/cytokine" & ", " & "cytokine induced" & ", " & "poor prognosis" & ", " & "driven cytokine" & ", " & "worsening syndrome" & ", " & "covid cytokine" & ", " & "in cytokine" & ", " & "includes cytokine release" & ", " & "treatment of cytokine" & ", " & "cytokine storm from the covid" & ", " & "in cytokine storm" & ", " & "worsening of cytokine" & ", " & "beginning of cytokine" & ", " & "covid pneumonia" & ", " & "cytokine inflammatory response" & ", " & "cytokine syndrom associated with covid19" & ", " & "cytokine driven" & ", " & "high inflammatory markers" & ", " & "covid positive" & ", " & "worsening tachypnea" & ", " & "developing cytokine" & ", " & "signs of cytokine" & ", " & "cytokine release from covid" & ", " & "cytokine storm from covid" & ", " & "inflammatory response and cytokine" & ", " & "w/cytokine storm" & ", " & "severe cytokine" & ", " & "COVID-19 induced organ failure" & ", " & "past cytokine" & ", " & "blunting the cytokine" & ", " & "SARS-CoV2 pneumonia" & ", " & "COVID-19 pneumonia and cytokine storm" & ", " & "Cytokine Release Syndrome associated with  Covid-19" & ", " & "have cytokine storm" & ", " & "covid-19 infection" & ", " & "for cytokine release" & ", " & "inflammatory response/cytokine" & ", " & "reflecting cytokine storm" & ", " & "2/2 to cytokine" & ", " & "likelihood of cytokine" & ", " & "covid-19 infection" & ", " & "cytokine mediated" & ", " & "likely from cytokine" & ", " & "combat cytokine release" & ", " & "midst of a cytokine" & ", " & "in light of cytokine" & ", " & "evidence for cytokine" & ", " & "covid-19 pneumonia" & ", " & "consistent with cytokine" & ", " & "continuing cytokine" & ", " & "probable cytokine" & ", " & "with cytokine" & ", " & "due to cytokine" & ", " & "covid19 induced cytokine" & ", " & "c/w cytokine" & ", " & "likely cytokine" & ", " & "presumed cytokine" & ", " & "evidence for cytokine" & ", " & "suspicion for cytokine" & ", " & "features for cytokine" & ", " & "cytokine blockade" & ", " & "2/2 cytokine" & ", " & "covid-19" & ", " & "experiencing cytokine" & ", " & "storm AKI" & ", " & "following cytokine" & ", " & "cytokine related" & ", " & "ongoing cytokine" & ", " & "most likely" & ", " & "highly consistent" & ", " & "consistent with cytokine" & ", " & "elevated inflammatory" & ", " & "Strong suspicion" & ", " & "induced cytokine" & ", " & "ongoing cytokine" & ", " & "continuing cytokine" & ", " & "evidence for cytokine" & ", " & "covid19 pneumonia" & ", " & "evidence of cytokine release" & ", " & "features of cytokine" & ", " & "storm syndrome" & ", " & "combat the cytokine" & ", " & "worsening due to cytokine" & ", " & "underlying COVID" & ", " & "worsening cytokine" & ", " & "ARDS")
        Dim oRegex_chunk As String() = Regex.Split(strDefinite, ",\s+(?=(?:(?:[^,]*'){2})*[^']*$?)", RegexOptions.IgnoreCase)
        Dim strPossible As String = ("post-cytokine" & ", " & "against cytokine" & ", " & "worsening sepsis" & ", " & "re cytokine" & ", " & "s/o covid19 infection/ cytokine" & ", " & "fend off a cytokine" & ", " & "increased inflammatory" & ", " & "virus/cytokine" & ", " & "setting of cytokine" & ", " & "indicators of cytokine" & ", " & "indicator of cytokine" & ", " & "likley cytokine" & ", " & "covid-cytokine" & ", " & "iL-6 receptor" & ", " & "cytokine (iL-6)" & ", " & "cytokine iL-6" & ", " & "cytokine may be" & ", " & "storm may be" & ", " & "/cytokine/" & ", " & """cytokine storm""" & ", " & "anti-cytokine" & ", " & "dec cytokine" & ", " & "cytokine modulation" & ", " & "cytokine panel" & ", " & "cytokine labs" & ", " & "inflammatory/cytokine" & ", " & "c/f cytokine" & ", " & "moderate cytokine" & ", " & "into the cytokine" & ", " & "cytokine panel" & ", " & "further cytokine" & ", " & "evolving cytokine" & ", " & "cytokine?" & ", " & "inflammatory response/ cytokine" & ", " & "dose for cytokine" & ", " & "reports of cytokine " & ", " & "cytokine activation" & ", " & "and cytokine storm" & ", " & "cytokine release" & ", " & "suspect cytokine" & ", " & "markers of cytokine" & ", " & "suspicion of cytokine" & ", " & "rising inflammatory" & ", " & "from cytokine" & ", " & "markers/cytokine" & ", " & "covid19 management" & ", " & "early cytokine storm" & ", " & "aki possible" & ", " & "cytokine surge" & ", " & "covid positive" & ", " & "cytokine storm soon" & ", " & "cytokine storm coming" & ", " & "suspected cytokine" & ", " & "suggestive of cytokine" & ", " & "high inflammation" & ", " & "covid protocol" & ", " & "for cytokine syndrome" & ", " & "check inflammatory" & ", " & "on ventilator" & ", " & "developed aki" & ", " & "concerned for cytokine" & ", " & "cytokine panel requested" & ", " & "caused by covid" & ", " & "likely to have had cytokine storm" & ", " & "positive sars-cov-2" & ", " & "assess cytokine" & ", " & "second cytokine storm" & ", " & "rather than cytokine" & ", " & "impending cytokine" & ", " & "trend inflammatory marker" & ", " & "corona virus infection" & ", " & "cytokine storm labs" & ", " & "cellular injury from SARS-CoV2" & ", " & "concern for development of cytokine" & ", " & "vs" & ", " & "predictors of cytokine storm" & ", " & "suggest cytokine storm" & ", " & "concern for cytokine" & ", " & "result of cytokine storm" & ", " & "inflammatory/CRS phase of COVID19" & ", " & "likely cytokine" & ", " & "possible cytokine" & ", " & "possible impending cytokine" & ", " & "evidence of cytokine" & ", " & "presumed cytokine" & ", " & "monitor for cytokine" & ", " & "may just be cytokine" & ", " & "secondary to cytokine" & ", " & "possibility of cytokine" & ", " & "possibility of AKI" & ", " & "consideration of cytokine" & ", " & "predictors of cytokine" & ", " & "suggest cytokine" & ", " & "sequella of sepsis/cytokine" & ", " & "onset of cytokine" & ", " & "generalized cytokine storm" & ", " & "Cytokine storm in setting" & ", " & "or cytokine storm" & ", " & "evolving ARDS/Cytokine" & ", " & "predict cytokine" & ", " & "either from cytokine" & ", " & "potential development of cytokine" & ", " & "suspected COVID19") ' & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "" & ", " & "")
        Dim oRegex1_chunk As String() = Regex.Split(strPossible, ",\s+(?=(?:(s?:[^,]*'){2})*[^']*$?)", RegexOptions.IgnoreCase)
        Dim i As Integer
        Dim n As Integer
        Dim m As Integer
        Dim dr As Data.DataRow

        Try

            Dim con As SqlConnection
            Dim cmd As SqlCommand
            Dim cmd_ret As SqlCommand
            Dim da As SqlDataAdapter
            Dim ds As New DataSet
            Dim ds_ret As New DataSet
            Dim docsid As String

            con = New SqlConnection("server=vhaconnlp1;database=vacs_tiu;integrated security=true")
            con.Open()

            cmd = New SqlCommand("select replace(snippet,'''',''),tiudocumentsid from Cytokine_storm_snips_20200520 ", con)
            da = New SqlDataAdapter(cmd)
            da.Fill(ds)



            For Each dr In ds.Tables(0).Rows
                Dim strPattern = ""
                Dim strPattern1 = ""
                Dim strRowVal = ds.Tables(0).Rows(i).Item(0).ToString
                docsid = ds.Tables(0).Rows(i).Item(1).ToString
                strRowVal = Replace(strRowVal, "cytokine storm-s/p", "cytokine storm sp").ToString
                strRowVal = strRowVal.Tolower()
                n = 0
                m = 0
                'Definite cases
                For Each strPattern In oRegex_chunk

                    strPattern = oRegex_chunk(n).ToLower()
                    strPattern = Replace(strPattern, "cytokine storm-s/p", "cytokine storm sp").ToString

                    If (strRowVal.Contains(strPattern).ToString = "True") Then
                        SqlContext.Pipe.Send("Definite Pattern match- " + strPattern + " ID " + docsid.ToString)
                        cmd_ret = New SqlCommand("insert into cytokine_lookup_regex(tiudocumentsid,snippet,cytokinecode) values (" + docsid + ", '" + strRowVal + "'," + "'definite')", con)
                        cmd_ret.ExecuteNonQuery()
                        Exit For
                    Else
                        strPattern = ""
                    End If
                    strPattern = ""
                    n = n + 1

                Next

                'Possible cases
                For Each strPattern1 In oRegex1_chunk

                    strPattern1 = oRegex1_chunk(m).ToLower()

                    If (strRowVal.Contains(strPattern1).ToString = "True") Then
                        'SqlContext.Pipe.Send("Possible pattern match - " + strPattern1 + " ID " + docsid.ToString)
                        cmd_ret = New SqlCommand("insert into cytokine_lookup_regex(tiudocumentsid,snippet,cytokinecode) select " + docsid + ", '" + strRowVal + "'," + "'possible' WHERE NOT EXISTS (SELECT snippet FROM cytokine_lookup_regex WHERE snippet = '" + strRowVal + "')", con)
                        cmd_ret.ExecuteNonQuery()
                        Exit For
                    Else
                        strPattern1 = ""
                    End If
                    strPattern1 = ""
                    m = m + 1

                Next

                'Unlikely


                cmd_ret = New SqlCommand("insert into cytokine_lookup_regex(tiudocumentsid,snippet,cytokinecode) select " + docsid + ", '" + strRowVal + "'," + "'unlikely' WHERE NOT EXISTS (SELECT snippet FROM cytokine_lookup_regex WHERE snippet = '" + strRowVal + "')", con)
                'SqlContext.Pipe.Send(cmd_ret.CommandText.ToString) 'ds.Tables(0).Rows(i).Item(1).ToString)
                cmd_ret.ExecuteNonQuery()
                i = i + 1
                'SqlContext.Pipe.Send(i.ToString)
            Next

            con.Close()

        Catch ex As Exception
            SqlContext.Pipe.Send(ex.Message)
        End Try


    End Sub


    Public Shared Function fn_return(ByVal formatstring As SqlTypes.SqlString) As String
        If formatstring.IsNull Then
            Return formatstring.IsNull()
        Else
            Return formatstring.Value
        End If

    End Function

End Class